import * as firebase from'firebase';
require('@firebase/firestore');

var firebaseConfig = {
    apiKey: "AIzaSyAvRkAutOI0WGJxtvExe2esn6DoEldU4pM",
    authDomain: "wireless-buzzer-43106.firebaseapp.com",
    databaseURL: "https://wireless-buzzer-43106-default-rtdb.firebaseio.com",
    projectId: "wireless-buzzer-43106",
    storageBucket: "wireless-buzzer-43106.appspot.com",
    messagingSenderId: "1070699292554",
    appId: "1:1070699292554:web:98c10de97e262b539a0a73",
    measurementId: "G-QCK47TJ62W"
  };
  // Initialize Firebase
 if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
 }
  export default firebase.firestore;